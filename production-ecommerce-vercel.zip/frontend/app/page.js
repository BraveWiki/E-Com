
export default function Home(){
 return <h1>E-Commerce Storefront</h1>
}
