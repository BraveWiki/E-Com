
export default function Admin(){
 return <h1>Admin Dashboard</h1>
}
